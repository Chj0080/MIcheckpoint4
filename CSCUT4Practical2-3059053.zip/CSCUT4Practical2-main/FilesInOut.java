import java.io.*;
import java.util.*;

public class FilesInOut 
{
	public static void main(String[] args) {
	    // Replace this with statements to set the file name (input) and file name (output).
	    String inputFileName = "input.txt"; // replace with your own input file name
	    String outputFileName = "output.html"; // replace with your own output file name
	    
	    // Set up a new Scanner to read the input file.
	    Scanner scanner = null;
	    try {
	        scanner = new Scanner(new File(inputFileName));
	    } catch (FileNotFoundException e) {
	        System.out.println("File not found: " + e.getMessage());
	        System.exit(1);
	    }
	    
	    // Set up a new PrintWriter to write the output file.
	    PrintWriter printWriter = null;
	    try {
	        printWriter = new PrintWriter(outputFileName);
	    } catch (FileNotFoundException e) {
	        System.out.println("File not found: " + e.getMessage());
	        System.exit(1);
	    }
	    
	    // Processing line by line would be sensible here.
	    // Initially, echo the text to System.out to check you are reading correctly.
	    // Then add code to modify the text to the output format.
	    while (scanner.hasNextLine()) {
	        String line = scanner.nextLine();
	        System.out.println(line); // echo the line to System.out
	        // modify the line as needed and write to output file
	        printWriter.println(line);
	    }
	    
	    // Close the input and output files.
	    scanner.close();
	    printWriter.close();
	    
	    // Finally, add code to read the filenames as arguments from the command line.
	    if (args.length == 2) {
	        inputFileName = args[0];
	        outputFileName = args[1];
	    } else {
	        System.out.println("Usage: java FilesInOut inputFileName outputFileName");
	        System.exit(1);
	    }
	} // main

} // FilesInOut